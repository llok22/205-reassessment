#!
from flask import Flask, render_template, request, session
import pymysql


app = Flask(__name__)

#connect database
db = pymysql.connect(host="localhost:3308", user="newuser", password="password", database="website_db")

newuser = "New Guest"

@app.route('/')
def index():
    if 'username' in session: #if user is log in 
        return render_template('Products.html')
    else: #if user is not log in 
        return render_template('home.html')


@app.route('/preorder', method=['POST'])
def preorder():
    # Get product ID to search product price
    P_ID = request.form ['product_id']
    mycursor = db.cursor()
    sql = "SELECT P_Price From product Where P_ID = %s"
    val = (P_ID)
    mycursor.execute(sql, val)
    

@app.route('/Sign_Up', methods=['GET', 'POST'])
def SignUp():
    # Get Username , Email , password, phonenumber
    if request.method == 'POST':
        username = request.form['name']
        userEmail = request.form['email']
        password = request.form ['password']
        UserPhNum = request.form['phone']
        SignUpmessage = ''
        
         
        # Add them into customer table
        MyCursor = db.cursor()
        sql = "insert Into customers (C_ID, C_NAME, C_Email, C_Password, Phone_Num) VALUES (NULL, %s, %s, %s, %s,)"
        val = (username, userEmail, password, UserPhNum)
        MyCursor.execute (sql, val)
        
        try:
            db.commit()
            sql = "INSERT INTO login (C_ID, C_Email, C_Name, C_Password) VALUES (%s, %s, %s, %s)"
            val = (MyCursor.lastrowid, userEmail, username, password)
            MyCursor.execute(sql, val)
            db.commit()
            SignUpmessage = 'SignUp Success'
            return render_template('Home.html', name= username, SignUpmessage = SignUpmessage)
        except:
            db.rollback()
            SignUpmessage = 'SignUp unsuccess, please enter again'
            return render_template('Home.html', name= username, SignUpmessage = SignUpmessage)
    
    return render_template('Home.html', name = newuser)
# find user in the login table
@app.route('/Login', methods= ['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        mycursor = db.cursor()
        sql = "SELECT C_ID From login Where C_Email = %s AND C_Password = %s"
        val = (email, password)
        mycursor.execute(sql, val)
        myresult = mycursor.fetchone()

        if myresult:
            session['email'] = email
            session['user_CID'] = myresult
            return render_template ('product.html')
        
        else:
            return render_template ('home.html')
    
    if 'email' in session:
        return render_template('home.html', name= session['username'])
    else:
        return render_template('home.html',name= newuser)
    

    if __name__ == '__main__':
        app.debug = True
        app.run(host= "0.0.0.", port=8000)
    


        
                
